import React, { useState } from 'react';
import {
  FlaskConical,
  Search,
  CheckCircle2,
  Clock,
  AlertTriangle,
  FileText,
  Printer,
  ShieldCheck,
} from 'lucide-react';
import { useHospital } from '../context/HospitalContext';

export const LabDiagnostics: React.FC = () => {
  const { patients, addNotification } = useHospital();
  const [searchQuery, setSearchQuery] = useState('');

  // Generate lab test requests from patients who have test orders
  const labOrders = [
    {
      id: 'LAB-9041',
      patientId: 'PAT-01',
      patientName: 'Eleanor Vance',
      testName: 'Complete Blood Count (CBC) with Differential',
      specimen: 'Whole Blood (EDTA)',
      priority: 'Routine',
      orderedBy: 'Dr. Sarah Jenkins, MD',
      status: 'Completed',
      result: 'WBC 6.8 K/uL, RBC 4.5 M/uL, Hgb 13.8 g/dL (All normal ranges)',
      reportedAt: 'Today, 09:30 AM',
    },
    {
      id: 'LAB-9042',
      patientId: 'PAT-01',
      patientName: 'Eleanor Vance',
      testName: 'Lipid Panel (Total, HDL, LDL, Triglycerides)',
      specimen: 'Serum (SST)',
      priority: 'Routine',
      orderedBy: 'Dr. Sarah Jenkins, MD',
      status: 'Completed',
      result: 'Total Chol: 188 mg/dL, HDL: 54 mg/dL, LDL: 110 mg/dL',
      reportedAt: 'Today, 10:15 AM',
    },
    {
      id: 'LAB-9043',
      patientId: 'PAT-02',
      patientName: 'Marcus Holloway',
      testName: 'Cardiac Troponin I (High Sensitivity STAT)',
      specimen: 'Plasma (Heparin)',
      priority: 'STAT',
      orderedBy: 'Dr. Julian Thorne, MD',
      status: 'Pending Analysis',
      result: 'Specimen in centrifugation',
      reportedAt: 'In Progress (ETA 15m)',
    },
    {
      id: 'LAB-9044',
      patientId: 'PAT-03',
      patientName: 'Clara Oswald',
      testName: 'Comprehensive Metabolic Panel (CMP-14)',
      specimen: 'Serum (SST)',
      priority: 'Urgent',
      orderedBy: 'Dr. Sarah Jenkins, MD',
      status: 'Completed',
      result: 'Glucose: 96 mg/dL, BUN: 14 mg/dL, Creatinine: 0.9 mg/dL',
      reportedAt: 'Today, 11:00 AM',
    },
  ];

  const filteredOrders = labOrders.filter((o) =>
    o.patientName.toLowerCase().includes(searchQuery.toLowerCase()) ||
    o.testName.toLowerCase().includes(searchQuery.toLowerCase()) ||
    o.id.toLowerCase().includes(searchQuery.toLowerCase())
  );

  return (
    <div className="p-4 lg:p-6 space-y-4 max-w-7xl mx-auto">
      {/* Top Banner */}
      <div className="bg-white rounded-xl border border-slate-200 shadow-sm p-4 sm:p-5 flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div>
          <div className="flex items-center gap-2 mb-1">
            <div className="w-8 h-8 rounded-lg bg-teal-50 text-teal-600 flex items-center justify-center font-bold">
              <FlaskConical className="w-4 h-4" />
            </div>
            <h2 className="text-base font-bold text-slate-900 tracking-tight">
              Hospital Pathology & Diagnostic Laboratory
            </h2>
            <span className="text-[10px] font-mono px-2 py-0.5 rounded bg-teal-50 text-teal-700 border border-teal-200 font-bold uppercase">
              CLIA & CAP ACCREDITED
            </span>
          </div>
          <p className="text-xs text-slate-500 max-w-2xl">
            Automated specimen tracking, analyzer results telemetry, reference range adjudication, and STAT emergency turnaround times.
          </p>
        </div>

        <div className="flex items-center gap-2 text-xs text-slate-500">
          <ShieldCheck className="w-4 h-4 text-emerald-600" />
          <span>Automated Analyzer Interface Active</span>
        </div>
      </div>

      {/* Lab Orders Table */}
      <div className="bg-white rounded-xl border border-slate-200 shadow-sm overflow-hidden flex flex-col">
        <div className="p-3.5 border-b border-slate-200 flex flex-col sm:flex-row items-start sm:items-center justify-between gap-3 bg-slate-50/50">
          <div className="flex items-center gap-2">
            <FlaskConical className="w-4 h-4 text-teal-600" />
            <h3 className="text-xs font-bold uppercase tracking-wider text-slate-800">
              Active Specimen Orders & Results ({filteredOrders.length})
            </h3>
          </div>

          <div className="relative w-full sm:w-64">
            <Search className="w-3.5 h-3.5 text-slate-400 absolute left-3 top-1/2 -translate-y-1/2" />
            <input
              type="text"
              placeholder="Filter test or patient..."
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              className="w-full bg-white border border-slate-300 rounded-lg py-1.5 pl-8 pr-3 text-xs focus:ring-2 focus:ring-teal-500/20 text-slate-800"
            />
          </div>
        </div>

        <div className="overflow-x-auto">
          <table className="w-full text-left border-collapse text-xs">
            <thead>
              <tr className="border-b border-slate-200 bg-slate-100/75 text-[10px] uppercase font-bold text-slate-500 tracking-wider">
                <th className="py-2.5 px-3">Order ID</th>
                <th className="py-2.5 px-3">Patient</th>
                <th className="py-2.5 px-3">Diagnostic Panel</th>
                <th className="py-2.5 px-3">Specimen</th>
                <th className="py-2.5 px-3">Acuity</th>
                <th className="py-2.5 px-3">Status</th>
                <th className="py-2.5 px-3">Reported Findings</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100 font-normal">
              {filteredOrders.map((order) => (
                <tr key={order.id} className="hover:bg-slate-50/80 transition-colors">
                  <td className="py-2.5 px-3 whitespace-nowrap font-mono font-bold text-slate-800">
                    {order.id}
                  </td>
                  <td className="py-2.5 px-3 whitespace-nowrap">
                    <div className="font-semibold text-slate-900">{order.patientName}</div>
                    <div className="text-[10px] text-slate-400 font-mono">{order.patientId}</div>
                  </td>
                  <td className="py-2.5 px-3 whitespace-nowrap text-slate-700 font-medium">
                    {order.testName}
                  </td>
                  <td className="py-2.5 px-3 whitespace-nowrap text-slate-500 font-mono text-[11px]">
                    {order.specimen}
                  </td>
                  <td className="py-2.5 px-3 whitespace-nowrap">
                    <span
                      className={`px-1.5 py-0.5 rounded text-[10px] font-bold ${
                        order.priority === 'STAT'
                          ? 'bg-rose-100 text-rose-700 animate-pulse'
                          : 'bg-slate-100 text-slate-600'
                      }`}
                    >
                      {order.priority}
                    </span>
                  </td>
                  <td className="py-2.5 px-3 whitespace-nowrap">
                    <span
                      className={`px-2 py-0.5 rounded text-[10px] font-bold ${
                        order.status === 'Completed'
                          ? 'bg-emerald-100 text-emerald-800'
                          : 'bg-amber-100 text-amber-800'
                      }`}
                    >
                      {order.status}
                    </span>
                  </td>
                  <td className="py-2.5 px-3 text-slate-700 font-mono text-[11px]">
                    {order.result}
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
};
