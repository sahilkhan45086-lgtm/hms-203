import React, { useState, useEffect } from 'react';
import {
  X,
  CalendarPlus,
  Clock,
  User,
  Stethoscope,
  AlertCircle,
  Activity,
  CheckCircle2,
  Calendar,
} from 'lucide-react';
import { useHospital } from '../context/HospitalContext';
import { AppointmentPriority } from '../types';

interface NewAppointmentModalProps {
  isOpen: boolean;
  onClose: () => void;
  presetDoctorId?: string;
  presetDate?: string;
  presetTimeSlot?: string;
}

export const NewAppointmentModal: React.FC<NewAppointmentModalProps> = ({
  isOpen,
  onClose,
  presetDoctorId,
  presetDate,
  presetTimeSlot,
}) => {
  const { patients, doctors, addAppointment, addNotification } = useHospital();

  const [patientId, setPatientId] = useState(patients[0]?.id || '');
  const [doctorId, setDoctorId] = useState(presetDoctorId || doctors[0]?.id || '');
  const [date, setDate] = useState(presetDate || new Date().toISOString().split('T')[0]);
  const [timeSlot, setTimeSlot] = useState(presetTimeSlot || '10:00 AM');
  const [priority, setPriority] = useState<AppointmentPriority>('Normal');
  const [chiefComplaint, setChiefComplaint] = useState('Routine clinical consultation & review');

  useEffect(() => {
    if (!isOpen) return;
    const handleKeyDown = (e: KeyboardEvent) => {
      if (e.key === 'Escape') {
        onClose();
      }
    };
    window.addEventListener('keydown', handleKeyDown);
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, [isOpen, onClose]);

  if (!isOpen) return null;

  const selectedPatient = patients.find((p) => p.id === patientId);
  const selectedDoc = doctors.find((d) => d.id === doctorId);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();

    if (!selectedPatient || !selectedDoc) {
      addNotification('Selection Missing', 'Please select both a patient and an attending doctor.', 'warning');
      return;
    }

    addAppointment({
      patientId: selectedPatient.id,
      patientName: `${selectedPatient.firstName} ${selectedPatient.lastName}`,
      patientAge: selectedPatient.age,
      patientGender: selectedPatient.gender,
      doctorId: selectedDoc.id,
      doctorName: selectedDoc.name,
      department: selectedDoc.department,
      date,
      timeSlot,
      status: 'Scheduled',
      priority,
      chiefComplaint,
      estimatedWaitMinutes: priority === 'Emergency' ? 0 : priority === 'Urgent' ? 5 : 15,
    });

    addNotification(
      'Appointment Confirmed',
      `Booked slot for ${selectedPatient.firstName} ${selectedPatient.lastName} with ${selectedDoc.name} on ${date} at ${timeSlot}.`,
      'success',
      selectedPatient.id
    );

    onClose();
  };

  const TIME_SLOTS = [
    '08:30 AM',
    '09:00 AM',
    '09:30 AM',
    '10:00 AM',
    '10:30 AM',
    '11:00 AM',
    '11:30 AM',
    '01:00 PM',
    '01:30 PM',
    '02:00 PM',
    '02:30 PM',
    '03:00 PM',
    '03:30 PM',
    '04:00 PM',
  ];

  return (
    <div
      onClick={(e) => {
        if (e.target === e.currentTarget) onClose();
      }}
      className="fixed inset-0 bg-slate-900/60 backdrop-blur-xs flex items-center justify-center p-3 sm:p-4 z-50 animate-in fade-in duration-150"
    >
      <div className="bg-white rounded-2xl border border-slate-200 shadow-2xl max-w-lg w-full overflow-hidden flex flex-col max-h-[92vh]">
        {/* Header with Classification Badge */}
        <div className="p-4 bg-slate-900 text-white flex items-center justify-between shrink-0">
          <div className="flex items-center gap-2.5">
            <div className="w-8 h-8 rounded-lg bg-emerald-600/30 border border-emerald-500/40 text-emerald-400 flex items-center justify-center font-bold">
              <CalendarPlus className="w-4.5 h-4.5" />
            </div>
            <div>
              <div className="flex items-center gap-2">
                <span className="text-[9px] font-bold uppercase tracking-wider text-emerald-400 bg-emerald-950/60 px-1.5 py-0.5 rounded border border-emerald-800">
                  Front Desk & Schedule
                </span>
              </div>
              <h2 className="font-bold text-sm text-white mt-0.5">Book Consultation Slot</h2>
            </div>
          </div>
          <button
            onClick={onClose}
            className="text-slate-400 hover:text-white p-1.5 rounded-lg hover:bg-slate-800 transition cursor-pointer"
            aria-label="Close modal"
          >
            <X className="w-4 h-4" />
          </button>
        </div>

        <form onSubmit={handleSubmit} className="p-5 overflow-y-auto space-y-4 text-xs">
          {/* Classification Section 1: Patient & Clinician Selection */}
          <div className="space-y-3 p-3 bg-slate-50 border border-slate-200/80 rounded-xl">
            <span className="text-[10px] font-bold text-slate-500 uppercase tracking-wider block">
              1. Patient & Attending Clinician
            </span>

            <div>
              <label className="text-[11px] font-semibold text-slate-700 block mb-1">
                Select Patient
              </label>
              <select
                value={patientId}
                onChange={(e) => setPatientId(e.target.value)}
                className="w-full bg-white border border-slate-300 rounded-lg p-2 text-xs font-medium focus:ring-2 focus:ring-blue-500 focus:border-blue-500 outline-none"
                required
              >
                {patients.map((p) => (
                  <option key={p.id} value={p.id}>
                    {p.firstName} {p.lastName} (MRN: {p.id}) — {p.age}y {p.gender} · {p.status}
                  </option>
                ))}
              </select>
            </div>

            <div>
              <label className="text-[11px] font-semibold text-slate-700 block mb-1">
                Attending Clinician & Specialty
              </label>
              <select
                value={doctorId}
                onChange={(e) => setDoctorId(e.target.value)}
                className="w-full bg-white border border-slate-300 rounded-lg p-2 text-xs font-medium focus:ring-2 focus:ring-blue-500 focus:border-blue-500 outline-none"
                required
              >
                {doctors.map((d) => (
                  <option key={d.id} value={d.id}>
                    {d.name} — {d.specialty} ({d.department}) · {d.isAvailable ? 'Available' : 'In Consult'}
                  </option>
                ))}
              </select>
            </div>
          </div>

          {/* Classification Section 2: Date, Time & Priority */}
          <div className="space-y-3 p-3 bg-slate-50 border border-slate-200/80 rounded-xl">
            <span className="text-[10px] font-bold text-slate-500 uppercase tracking-wider block">
              2. Schedule & Acuity
            </span>

            <div className="grid grid-cols-2 gap-3">
              <div>
                <label className="text-[11px] font-semibold text-slate-700 block mb-1">
                  Appointment Date
                </label>
                <input
                  type="date"
                  value={date}
                  onChange={(e) => setDate(e.target.value)}
                  className="w-full bg-white border border-slate-300 rounded-lg p-2 text-xs font-mono focus:ring-2 focus:ring-blue-500 outline-none"
                  required
                />
              </div>

              <div>
                <label className="text-[11px] font-semibold text-slate-700 block mb-1">
                  Consultation Time Slot
                </label>
                <select
                  value={timeSlot}
                  onChange={(e) => setTimeSlot(e.target.value)}
                  className="w-full bg-white border border-slate-300 rounded-lg p-2 text-xs font-medium focus:ring-2 focus:ring-blue-500 outline-none"
                >
                  {TIME_SLOTS.map((slot) => (
                    <option key={slot} value={slot}>
                      {slot}
                    </option>
                  ))}
                </select>
              </div>
            </div>

            <div>
              <label className="text-[11px] font-semibold text-slate-700 block mb-1.5">
                Acuity Priority
              </label>
              <div className="grid grid-cols-3 gap-2">
                {(['Normal', 'Urgent', 'Emergency'] as AppointmentPriority[]).map((pr) => {
                  const isSelected = priority === pr;
                  return (
                    <button
                      key={pr}
                      type="button"
                      onClick={() => setPriority(pr)}
                      className={`py-2 px-2.5 rounded-lg border text-xs font-semibold flex items-center justify-center gap-1.5 transition cursor-pointer ${
                        isSelected
                          ? pr === 'Emergency'
                            ? 'bg-rose-600 text-white border-rose-600 shadow-xs'
                            : pr === 'Urgent'
                            ? 'bg-amber-600 text-white border-amber-600 shadow-xs'
                            : 'bg-blue-600 text-white border-blue-600 shadow-xs'
                          : 'bg-white text-slate-700 border-slate-200 hover:bg-slate-100'
                      }`}
                    >
                      {pr === 'Emergency' ? (
                        <Activity className="w-3.5 h-3.5" />
                      ) : pr === 'Urgent' ? (
                        <AlertCircle className="w-3.5 h-3.5" />
                      ) : (
                        <Clock className="w-3.5 h-3.5" />
                      )}
                      <span>{pr}</span>
                    </button>
                  );
                })}
              </div>
            </div>
          </div>

          {/* Classification Section 3: Clinical Reason */}
          <div>
            <label className="text-[11px] font-semibold text-slate-700 block mb-1">
              Clinical Reason / Chief Complaint
            </label>
            <textarea
              rows={2}
              value={chiefComplaint}
              onChange={(e) => setChiefComplaint(e.target.value)}
              className="w-full bg-white border border-slate-300 rounded-lg p-2.5 text-xs focus:ring-2 focus:ring-blue-500 outline-none"
              placeholder="Primary symptoms, follow-up purpose, or consultation objective..."
            />
          </div>

          {/* Footer Controls */}
          <div className="pt-3 border-t border-slate-200 flex items-center justify-between">
            <button
              type="button"
              onClick={onClose}
              className="px-4 py-2 bg-slate-100 hover:bg-slate-200 text-slate-700 rounded-lg font-semibold text-xs cursor-pointer transition"
            >
              Cancel
            </button>
            <button
              type="submit"
              className="px-5 py-2 bg-emerald-600 hover:bg-emerald-500 text-white rounded-lg font-semibold text-xs shadow-xs flex items-center gap-1.5 cursor-pointer transition"
            >
              <CheckCircle2 className="w-4 h-4" />
              <span>Confirm & Book Slot</span>
            </button>
          </div>
        </form>
      </div>
    </div>
  );
};

