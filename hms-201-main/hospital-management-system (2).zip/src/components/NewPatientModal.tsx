import React, { useState, useEffect } from 'react';
import {
  X,
  UserPlus,
  User,
  Phone,
  Mail,
  MapPin,
  Calendar,
  ShieldCheck,
  Stethoscope,
  HeartPulse,
  AlertCircle,
  Building2,
  CheckCircle2,
  CreditCard,
  FileText,
} from 'lucide-react';
import { useHospital } from '../context/HospitalContext';
import { BloodGroup, PatientStatus, Patient } from '../types';

interface NewPatientModalProps {
  isOpen: boolean;
  onClose: () => void;
  onPatientCreated?: (id: string) => void;
  initialPatientId?: string;
}

export const NewPatientModal: React.FC<NewPatientModalProps> = ({
  isOpen,
  onClose,
  onPatientCreated,
  initialPatientId,
}) => {
  const { patients, doctors, wardBeds, addPatient, updatePatient, addNotification } = useHospital();

  const [activeTab, setActiveTab] = useState<'demographics' | 'contact' | 'clinical' | 'insurance'>('demographics');

  // Demographics
  const [title, setTitle] = useState('Mr.');
  const [firstName, setFirstName] = useState('');
  const [middleName, setMiddleName] = useState('');
  const [lastName, setLastName] = useState('');
  const [dob, setDob] = useState('1990-01-01');
  const [gender, setGender] = useState<'Male' | 'Female' | 'Other'>('Male');
  const [bloodGroup, setBloodGroup] = useState<BloodGroup>('O+');
  const [maritalStatus, setMaritalStatus] = useState<'Single' | 'Married' | 'Divorced' | 'Widowed'>('Single');

  // Contact & ID
  const [phone, setPhone] = useState('');
  const [email, setEmail] = useState('');
  const [nationalId, setNationalId] = useState('');
  const [passportNo, setPassportNo] = useState('');
  const [address, setAddress] = useState('');
  const [city, setCity] = useState('Metropolis');
  const [emergencyName, setEmergencyName] = useState('');
  const [emergencyRelation, setEmergencyRelation] = useState('Spouse');
  const [emergencyPhone, setEmergencyPhone] = useState('');

  // Clinical & Admission
  const [status, setStatus] = useState<PatientStatus>('Outpatient');
  const [department, setDepartment] = useState('General Medicine');
  const [doctorId, setDoctorId] = useState(doctors[0]?.id || '');
  const [wardOrRoom, setWardOrRoom] = useState('');
  const [chiefComplaint, setChiefComplaint] = useState('');
  const [allergiesInput, setAllergiesInput] = useState('');
  const [chronicInput, setChronicInput] = useState('');

  // Insurance & Billing
  const [payMode, setPayMode] = useState<'Self' | 'Company' | 'Insurance'>('Insurance');
  const [insuranceProvider, setInsuranceProvider] = useState('MetLife Health');
  const [policyNumber, setPolicyNumber] = useState('POL-992014');
  const [copayPercent, setCopayPercent] = useState(20);

  // Auto-calculate age from DOB
  const calculateAge = (birthDateString: string): number => {
    if (!birthDateString) return 30;
    const today = new Date();
    const birthDate = new Date(birthDateString);
    let age = today.getFullYear() - birthDate.getFullYear();
    const m = today.getMonth() - birthDate.getMonth();
    if (m < 0 || (m === 0 && today.getDate() < birthDate.getDate())) {
      age--;
    }
    return Math.max(0, age);
  };

  const calculatedAge = calculateAge(dob);

  // Pre-fill if editing existing
  useEffect(() => {
    if (initialPatientId) {
      const existing = patients.find((p) => p.id === initialPatientId);
      if (existing) {
        setTitle(existing.title || 'Mr.');
        setFirstName(existing.firstName || '');
        setMiddleName(existing.middleName || '');
        setLastName(existing.lastName || '');
        setDob(existing.dob || '1990-01-01');
        setGender(existing.gender || 'Male');
        setBloodGroup(existing.bloodGroup || 'O+');
        setMaritalStatus(existing.maritalStatus || 'Single');
        setPhone(existing.phone || '');
        setEmail(existing.email || '');
        setNationalId(existing.emiratesId || '');
        setPassportNo(existing.passportNo || '');
        setAddress(existing.address || '');
        setEmergencyName(existing.emergencyContact?.name || '');
        setEmergencyRelation(existing.emergencyContact?.relationship || 'Spouse');
        setEmergencyPhone(existing.emergencyContact?.phone || '');
        setStatus(existing.status || 'Outpatient');
        setDepartment(existing.department || 'General Medicine');
        setDoctorId(existing.primaryPhysicianId || doctors[0]?.id || '');
        setWardOrRoom(existing.wardOrRoom || '');
        setChiefComplaint(existing.purposeOfVisit || '');
        setAllergiesInput(existing.allergies?.map((a) => a.allergen).join(', ') || '');
        setChronicInput(existing.chronicConditions?.join(', ') || '');
        setInsuranceProvider(existing.insurance?.provider || 'MetLife Health');
        setPolicyNumber(existing.insurance?.policyNumber || 'POL-992014');
        setCopayPercent(existing.insurance?.copayPercentage || 20);
      }
    }
  }, [initialPatientId, patients, doctors]);

  useEffect(() => {
    if (!isOpen) return;
    const handleKeyDown = (e: KeyboardEvent) => {
      if (e.key === 'Escape') {
        onClose();
      }
    };
    window.addEventListener('keydown', handleKeyDown);
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, [isOpen, onClose]);

  if (!isOpen) return null;

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();

    if (!firstName.trim() || !lastName.trim()) {
      addNotification('Validation Error', 'First name and last name are required.', 'warning');
      return;
    }

    const assignedDoctor = doctors.find((d) => d.id === doctorId) || doctors[0];

    const parsedAllergies = allergiesInput
      .split(',')
      .map((s) => s.trim())
      .filter(Boolean)
      .map((item) => ({
        allergen: item,
        severity: 'Moderate' as const,
      }));

    const parsedChronic = chronicInput
      .split(',')
      .map((s) => s.trim())
      .filter(Boolean);

    if (initialPatientId) {
      updatePatient(initialPatientId, {
        title,
        firstName: firstName.trim(),
        middleName: middleName.trim(),
        lastName: lastName.trim(),
        dob,
        age: calculatedAge,
        gender,
        bloodGroup,
        maritalStatus,
        phone,
        email,
        emiratesId: nationalId,
        passportNo,
        address: `${address}${city ? `, ${city}` : ''}`,
        emergencyContact: {
          name: emergencyName || 'Next of Kin',
          relationship: emergencyRelation || 'Family',
          phone: emergencyPhone || phone,
        },
        status,
        department,
        primaryPhysicianId: assignedDoctor?.id || 'DOC-01',
        primaryPhysicianName: assignedDoctor?.name || 'Attending Physician',
        wardOrRoom: status === 'Outpatient' ? undefined : wardOrRoom || undefined,
        purposeOfVisit: chiefComplaint,
        allergies: parsedAllergies,
        chronicConditions: parsedChronic,
        insurance: {
          provider: insuranceProvider,
          policyNumber,
          groupNumber: 'GRP-2026',
          validUntil: '2027-12-31',
          copayPercentage: copayPercent,
          status: 'Active',
          verifiedAt: new Date().toISOString(),
        },
      });

      addNotification(
        'Patient Record Updated',
        `Successfully updated record for ${firstName} ${lastName}.`,
        'success',
        initialPatientId
      );

      if (onPatientCreated) {
        onPatientCreated(initialPatientId);
      }
      onClose();
      return;
    }

    // Register new patient
    const newPatient = addPatient({
      title,
      firstName: firstName.trim(),
      middleName: middleName.trim(),
      lastName: lastName.trim(),
      dob,
      age: calculatedAge,
      gender,
      bloodGroup,
      maritalStatus,
      phone: phone || '+1 (555) 234-5678',
      email: email || `${firstName.toLowerCase()}.${lastName.toLowerCase()}@hospital.org`,
      address: address ? `${address}, ${city}` : '100 Medical Center Way, Metro City',
      emiratesId: nationalId,
      passportNo,
      emergencyContact: {
        name: emergencyName || 'Next of Kin',
        relationship: emergencyRelation || 'Family',
        phone: emergencyPhone || phone || '+1 (555) 999-0000',
      },
      status,
      department,
      primaryPhysicianId: assignedDoctor?.id || 'DOC-01',
      primaryPhysicianName: assignedDoctor?.name || 'Attending Physician',
      wardOrRoom: status === 'Outpatient' ? undefined : wardOrRoom || (status === 'Inpatient' ? 'Ward A - Room 102' : undefined),
      purposeOfVisit: chiefComplaint || 'Admission & Clinical Examination',
      allergies: parsedAllergies,
      chronicConditions: parsedChronic,
      insurance: {
        provider: payMode === 'Self' ? 'Self-Pay' : insuranceProvider,
        policyNumber: payMode === 'Self' ? 'CASH-PATIENT' : policyNumber,
        groupNumber: 'GRP-2026',
        validUntil: '2027-12-31',
        copayPercentage: payMode === 'Self' ? 100 : copayPercent,
        status: 'Active',
        verifiedAt: new Date().toISOString(),
      },
      payMode,
    });

    addNotification(
      'Patient Admitted Successfully',
      `${newPatient.firstName} ${newPatient.lastName} (${newPatient.id}) admitted as ${status}.`,
      'success',
      newPatient.id
    );

    if (onPatientCreated) {
      onPatientCreated(newPatient.id);
    }

    onClose();
  };

  const availableBeds = wardBeds.filter((b) => b.status === 'Available');

  return (
    <div
      onClick={(e) => {
        if (e.target === e.currentTarget) onClose();
      }}
      className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-4 bg-slate-900/60 backdrop-blur-xs animate-in fade-in duration-150"
    >
      <div className="bg-white rounded-xl shadow-2xl border border-slate-200 max-w-3xl w-full max-h-[92vh] flex flex-col overflow-hidden">
        {/* Header */}
        <div className="px-6 py-4 bg-slate-900 text-white flex items-center justify-between border-b border-slate-800">
          <div className="flex items-center gap-3">
            <div className="w-9 h-9 rounded-lg bg-blue-600/30 border border-blue-500/40 flex items-center justify-center text-blue-400">
              <UserPlus className="w-5 h-5" />
            </div>
            <div>
              <h2 className="font-semibold text-base text-white">
                {initialPatientId ? 'Update Patient Record' : 'Patient Admission & EMR Registration'}
              </h2>
              <p className="text-xs text-slate-400">
                MedCore Clinical Information System — Intake & Master Patient Index
              </p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="text-slate-400 hover:text-white p-1.5 rounded-lg hover:bg-slate-800 transition-colors cursor-pointer"
            aria-label="Close modal"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Tab Navigation */}
        <div className="flex border-b border-slate-200 bg-slate-50 px-6 gap-2 text-xs font-medium pt-2">
          <button
            type="button"
            onClick={() => setActiveTab('demographics')}
            className={`pb-2.5 px-3 border-b-2 flex items-center gap-1.5 transition-colors cursor-pointer ${
              activeTab === 'demographics'
                ? 'border-blue-600 text-blue-600 font-semibold'
                : 'border-transparent text-slate-600 hover:text-slate-900'
            }`}
          >
            <User className="w-3.5 h-3.5" />
            Demographics
          </button>
          <button
            type="button"
            onClick={() => setActiveTab('contact')}
            className={`pb-2.5 px-3 border-b-2 flex items-center gap-1.5 transition-colors cursor-pointer ${
              activeTab === 'contact'
                ? 'border-blue-600 text-blue-600 font-semibold'
                : 'border-transparent text-slate-600 hover:text-slate-900'
            }`}
          >
            <Phone className="w-3.5 h-3.5" />
            Contact & ID
          </button>
          <button
            type="button"
            onClick={() => setActiveTab('clinical')}
            className={`pb-2.5 px-3 border-b-2 flex items-center gap-1.5 transition-colors cursor-pointer ${
              activeTab === 'clinical'
                ? 'border-blue-600 text-blue-600 font-semibold'
                : 'border-transparent text-slate-600 hover:text-slate-900'
            }`}
          >
            <Stethoscope className="w-3.5 h-3.5" />
            Clinical & Admission
          </button>
          <button
            type="button"
            onClick={() => setActiveTab('insurance')}
            className={`pb-2.5 px-3 border-b-2 flex items-center gap-1.5 transition-colors cursor-pointer ${
              activeTab === 'insurance'
                ? 'border-blue-600 text-blue-600 font-semibold'
                : 'border-transparent text-slate-600 hover:text-slate-900'
            }`}
          >
            <CreditCard className="w-3.5 h-3.5" />
            Insurance & Billing
          </button>
        </div>

        {/* Form Body */}
        <form onSubmit={handleSubmit} className="flex-1 overflow-y-auto p-6 space-y-4">
          {/* TAB 1: DEMOGRAPHICS */}
          {activeTab === 'demographics' && (
            <div className="space-y-4">
              <div className="grid grid-cols-1 sm:grid-cols-4 gap-3">
                <div>
                  <label className="text-xs font-medium text-slate-700 block mb-1">Prefix / Title</label>
                  <select
                    value={title}
                    onChange={(e) => setTitle(e.target.value)}
                    className="w-full bg-white border border-slate-300 rounded-lg p-2 text-xs focus:ring-2 focus:ring-blue-500 focus:outline-hidden"
                  >
                    <option value="Mr.">Mr.</option>
                    <option value="Mrs.">Mrs.</option>
                    <option value="Ms.">Ms.</option>
                    <option value="Dr.">Dr.</option>
                    <option value="Master">Master</option>
                  </select>
                </div>
                <div>
                  <label className="text-xs font-medium text-slate-700 block mb-1">
                    First Name <span className="text-red-500">*</span>
                  </label>
                  <input
                    type="text"
                    value={firstName}
                    onChange={(e) => setFirstName(e.target.value)}
                    placeholder="e.g. John"
                    required
                    className="w-full bg-white border border-slate-300 rounded-lg p-2 text-xs focus:ring-2 focus:ring-blue-500 focus:outline-hidden"
                  />
                </div>
                <div>
                  <label className="text-xs font-medium text-slate-700 block mb-1">Middle Name</label>
                  <input
                    type="text"
                    value={middleName}
                    onChange={(e) => setMiddleName(e.target.value)}
                    placeholder="Optional"
                    className="w-full bg-white border border-slate-300 rounded-lg p-2 text-xs focus:ring-2 focus:ring-blue-500 focus:outline-hidden"
                  />
                </div>
                <div>
                  <label className="text-xs font-medium text-slate-700 block mb-1">
                    Last Name <span className="text-red-500">*</span>
                  </label>
                  <input
                    type="text"
                    value={lastName}
                    onChange={(e) => setLastName(e.target.value)}
                    placeholder="e.g. Doe"
                    required
                    className="w-full bg-white border border-slate-300 rounded-lg p-2 text-xs focus:ring-2 focus:ring-blue-500 focus:outline-hidden"
                  />
                </div>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
                <div>
                  <label className="text-xs font-medium text-slate-700 block mb-1">Date of Birth</label>
                  <div className="relative">
                    <input
                      type="date"
                      value={dob}
                      onChange={(e) => setDob(e.target.value)}
                      max={new Date().toISOString().split('T')[0]}
                      className="w-full bg-white border border-slate-300 rounded-lg p-2 text-xs focus:ring-2 focus:ring-blue-500 focus:outline-hidden"
                    />
                  </div>
                </div>
                <div>
                  <label className="text-xs font-medium text-slate-700 block mb-1">Calculated Age</label>
                  <div className="w-full bg-slate-100 border border-slate-200 rounded-lg p-2 text-xs text-slate-700 font-semibold">
                    {calculatedAge} years old
                  </div>
                </div>
                <div>
                  <label className="text-xs font-medium text-slate-700 block mb-1">Gender</label>
                  <select
                    value={gender}
                    onChange={(e) => setGender(e.target.value as any)}
                    className="w-full bg-white border border-slate-300 rounded-lg p-2 text-xs focus:ring-2 focus:ring-blue-500 focus:outline-hidden"
                  >
                    <option value="Male">Male</option>
                    <option value="Female">Female</option>
                    <option value="Other">Other</option>
                  </select>
                </div>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                <div>
                  <label className="text-xs font-medium text-slate-700 block mb-1">Blood Group</label>
                  <select
                    value={bloodGroup}
                    onChange={(e) => setBloodGroup(e.target.value as BloodGroup)}
                    className="w-full bg-white border border-slate-300 rounded-lg p-2 text-xs focus:ring-2 focus:ring-blue-500 focus:outline-hidden"
                  >
                    <option value="A+">A Positive (A+)</option>
                    <option value="A-">A Negative (A-)</option>
                    <option value="B+">B Positive (B+)</option>
                    <option value="B-">B Negative (B-)</option>
                    <option value="AB+">AB Positive (AB+)</option>
                    <option value="AB-">AB Negative (AB-)</option>
                    <option value="O+">O Positive (O+)</option>
                    <option value="O-">O Negative (O-)</option>
                  </select>
                </div>
                <div>
                  <label className="text-xs font-medium text-slate-700 block mb-1">Marital Status</label>
                  <select
                    value={maritalStatus}
                    onChange={(e) => setMaritalStatus(e.target.value as any)}
                    className="w-full bg-white border border-slate-300 rounded-lg p-2 text-xs focus:ring-2 focus:ring-blue-500 focus:outline-hidden"
                  >
                    <option value="Single">Single</option>
                    <option value="Married">Married</option>
                    <option value="Divorced">Divorced</option>
                    <option value="Widowed">Widowed</option>
                  </select>
                </div>
              </div>
            </div>
          )}

          {/* TAB 2: CONTACT & IDENTIFICATION */}
          {activeTab === 'contact' && (
            <div className="space-y-4">
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                <div>
                  <label className="text-xs font-medium text-slate-700 block mb-1">Primary Phone Number</label>
                  <div className="relative">
                    <Phone className="w-3.5 h-3.5 text-slate-400 absolute left-2.5 top-3" />
                    <input
                      type="tel"
                      value={phone}
                      onChange={(e) => setPhone(e.target.value)}
                      placeholder="+1 (555) 000-0000"
                      className="w-full bg-white border border-slate-300 rounded-lg pl-8 pr-3 py-2 text-xs focus:ring-2 focus:ring-blue-500 focus:outline-hidden"
                    />
                  </div>
                </div>
                <div>
                  <label className="text-xs font-medium text-slate-700 block mb-1">Email Address</label>
                  <div className="relative">
                    <Mail className="w-3.5 h-3.5 text-slate-400 absolute left-2.5 top-3" />
                    <input
                      type="email"
                      value={email}
                      onChange={(e) => setEmail(e.target.value)}
                      placeholder="patient@email.com"
                      className="w-full bg-white border border-slate-300 rounded-lg pl-8 pr-3 py-2 text-xs focus:ring-2 focus:ring-blue-500 focus:outline-hidden"
                    />
                  </div>
                </div>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                <div>
                  <label className="text-xs font-medium text-slate-700 block mb-1">National ID / Emirates ID / SSN</label>
                  <input
                    type="text"
                    value={nationalId}
                    onChange={(e) => setNationalId(e.target.value)}
                    placeholder="784-1990-1234567-1"
                    className="w-full bg-white border border-slate-300 rounded-lg p-2 text-xs focus:ring-2 focus:ring-blue-500 focus:outline-hidden"
                  />
                </div>
                <div>
                  <label className="text-xs font-medium text-slate-700 block mb-1">Passport Number</label>
                  <input
                    type="text"
                    value={passportNo}
                    onChange={(e) => setPassportNo(e.target.value)}
                    placeholder="N98234120"
                    className="w-full bg-white border border-slate-300 rounded-lg p-2 text-xs focus:ring-2 focus:ring-blue-500 focus:outline-hidden"
                  />
                </div>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
                <div className="sm:col-span-2">
                  <label className="text-xs font-medium text-slate-700 block mb-1">Residential Street Address</label>
                  <input
                    type="text"
                    value={address}
                    onChange={(e) => setAddress(e.target.value)}
                    placeholder="42 Medical Plaza, Suite 300"
                    className="w-full bg-white border border-slate-300 rounded-lg p-2 text-xs focus:ring-2 focus:ring-blue-500 focus:outline-hidden"
                  />
                </div>
                <div>
                  <label className="text-xs font-medium text-slate-700 block mb-1">City / Region</label>
                  <input
                    type="text"
                    value={city}
                    onChange={(e) => setCity(e.target.value)}
                    placeholder="Metropolis"
                    className="w-full bg-white border border-slate-300 rounded-lg p-2 text-xs focus:ring-2 focus:ring-blue-500 focus:outline-hidden"
                  />
                </div>
              </div>

              <div className="pt-2 border-t border-slate-200">
                <h4 className="text-xs font-semibold text-slate-800 mb-2">Emergency Contact</h4>
                <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
                  <div>
                    <label className="text-[11px] text-slate-600 block mb-1">Contact Name</label>
                    <input
                      type="text"
                      value={emergencyName}
                      onChange={(e) => setEmergencyName(e.target.value)}
                      placeholder="Jane Doe"
                      className="w-full bg-white border border-slate-300 rounded-lg p-2 text-xs focus:ring-2 focus:ring-blue-500 focus:outline-hidden"
                    />
                  </div>
                  <div>
                    <label className="text-[11px] text-slate-600 block mb-1">Relationship</label>
                    <input
                      type="text"
                      value={emergencyRelation}
                      onChange={(e) => setEmergencyRelation(e.target.value)}
                      placeholder="Spouse / Parent / Sibling"
                      className="w-full bg-white border border-slate-300 rounded-lg p-2 text-xs focus:ring-2 focus:ring-blue-500 focus:outline-hidden"
                    />
                  </div>
                  <div>
                    <label className="text-[11px] text-slate-600 block mb-1">Emergency Phone</label>
                    <input
                      type="tel"
                      value={emergencyPhone}
                      onChange={(e) => setEmergencyPhone(e.target.value)}
                      placeholder="+1 (555) 999-1234"
                      className="w-full bg-white border border-slate-300 rounded-lg p-2 text-xs focus:ring-2 focus:ring-blue-500 focus:outline-hidden"
                    />
                  </div>
                </div>
              </div>
            </div>
          )}

          {/* TAB 3: CLINICAL & ADMISSION */}
          {activeTab === 'clinical' && (
            <div className="space-y-4">
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                <div>
                  <label className="text-xs font-medium text-slate-700 block mb-1">Admission Status</label>
                  <select
                    value={status}
                    onChange={(e) => setStatus(e.target.value as PatientStatus)}
                    className="w-full bg-white border border-slate-300 rounded-lg p-2 text-xs font-medium focus:ring-2 focus:ring-blue-500 focus:outline-hidden"
                  >
                    <option value="Outpatient">Outpatient (OPD Walk-in / Scheduled)</option>
                    <option value="Inpatient">Inpatient (Ward Admission)</option>
                    <option value="Emergency">Emergency (Immediate ER / STAT)</option>
                    <option value="Observation">Observation (Day-Care / Clinical Stay)</option>
                  </select>
                </div>
                <div>
                  <label className="text-xs font-medium text-slate-700 block mb-1">Clinical Department</label>
                  <select
                    value={department}
                    onChange={(e) => setDepartment(e.target.value)}
                    className="w-full bg-white border border-slate-300 rounded-lg p-2 text-xs focus:ring-2 focus:ring-blue-500 focus:outline-hidden"
                  >
                    <option value="General Medicine">General Medicine</option>
                    <option value="Cardiology">Cardiology</option>
                    <option value="Emergency Medicine">Emergency Medicine</option>
                    <option value="Orthopedics">Orthopedics</option>
                    <option value="Pediatrics">Pediatrics</option>
                    <option value="Neurology">Neurology</option>
                    <option value="Oncology">Oncology</option>
                    <option value="Pulmonology">Pulmonology</option>
                  </select>
                </div>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                <div>
                  <label className="text-xs font-medium text-slate-700 block mb-1">Attending Physician</label>
                  <select
                    value={doctorId}
                    onChange={(e) => setDoctorId(e.target.value)}
                    className="w-full bg-white border border-slate-300 rounded-lg p-2 text-xs focus:ring-2 focus:ring-blue-500 focus:outline-hidden"
                  >
                    {doctors.map((d) => (
                      <option key={d.id} value={d.id}>
                        {d.name} — {d.specialty} ({d.department})
                      </option>
                    ))}
                  </select>
                </div>

                <div>
                  <label className="text-xs font-medium text-slate-700 block mb-1">
                    {status === 'Outpatient' ? 'Consultation Room' : 'Assigned Ward Bed'}
                  </label>
                  {status === 'Outpatient' ? (
                    <input
                      type="text"
                      value={wardOrRoom}
                      onChange={(e) => setWardOrRoom(e.target.value)}
                      placeholder="e.g. OPD Room 104"
                      className="w-full bg-white border border-slate-300 rounded-lg p-2 text-xs focus:ring-2 focus:ring-blue-500 focus:outline-hidden"
                    />
                  ) : (
                    <select
                      value={wardOrRoom}
                      onChange={(e) => setWardOrRoom(e.target.value)}
                      className="w-full bg-white border border-slate-300 rounded-lg p-2 text-xs focus:ring-2 focus:ring-blue-500 focus:outline-hidden"
                    >
                      <option value="">-- Select Available Hospital Bed --</option>
                      {availableBeds.map((bed) => (
                        <option key={bed.id} value={bed.bedNumber}>
                          {bed.bedNumber} ({bed.wardName} - {bed.roomType})
                        </option>
                      ))}
                      {!availableBeds.some((b) => b.bedNumber === wardOrRoom) && wardOrRoom && (
                        <option value={wardOrRoom}>{wardOrRoom} (Currently Assigned)</option>
                      )}
                    </select>
                  )}
                </div>
              </div>

              <div>
                <label className="text-xs font-medium text-slate-700 block mb-1">Chief Complaint / Purpose of Visit</label>
                <textarea
                  value={chiefComplaint}
                  onChange={(e) => setChiefComplaint(e.target.value)}
                  placeholder="Describe patient's symptoms, presentation, or referral reason..."
                  rows={2}
                  className="w-full bg-white border border-slate-300 rounded-lg p-2 text-xs focus:ring-2 focus:ring-blue-500 focus:outline-hidden"
                />
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                <div>
                  <label className="text-xs font-medium text-slate-700 block mb-1">
                    Known Allergies <span className="text-slate-400 font-normal">(comma-separated)</span>
                  </label>
                  <input
                    type="text"
                    value={allergiesInput}
                    onChange={(e) => setAllergiesInput(e.target.value)}
                    placeholder="e.g. Penicillin, Latex, NSAIDs"
                    className="w-full bg-white border border-slate-300 rounded-lg p-2 text-xs focus:ring-2 focus:ring-blue-500 focus:outline-hidden"
                  />
                </div>
                <div>
                  <label className="text-xs font-medium text-slate-700 block mb-1">
                    Chronic Conditions <span className="text-slate-400 font-normal">(comma-separated)</span>
                  </label>
                  <input
                    type="text"
                    value={chronicInput}
                    onChange={(e) => setChronicInput(e.target.value)}
                    placeholder="e.g. Hypertension, Type 2 Diabetes"
                    className="w-full bg-white border border-slate-300 rounded-lg p-2 text-xs focus:ring-2 focus:ring-blue-500 focus:outline-hidden"
                  />
                </div>
              </div>
            </div>
          )}

          {/* TAB 4: INSURANCE & BILLING */}
          {activeTab === 'insurance' && (
            <div className="space-y-4">
              <div>
                <label className="text-xs font-medium text-slate-700 block mb-1">Payment Mode</label>
                <div className="grid grid-cols-3 gap-3">
                  {(['Insurance', 'Self', 'Company'] as const).map((mode) => (
                    <button
                      key={mode}
                      type="button"
                      onClick={() => setPayMode(mode)}
                      className={`p-3 rounded-lg border text-xs font-medium text-center transition-all cursor-pointer ${
                        payMode === mode
                          ? 'border-blue-600 bg-blue-50/50 text-blue-800 shadow-xs'
                          : 'border-slate-200 bg-white text-slate-600 hover:bg-slate-50'
                      }`}
                    >
                      <div className="font-semibold">{mode === 'Self' ? 'Self-Pay / Cash' : mode}</div>
                      <div className="text-[10px] text-slate-500 mt-0.5">
                        {mode === 'Insurance'
                          ? 'Direct TPA Billing'
                          : mode === 'Self'
                          ? 'Immediate Patient Payment'
                          : 'Corporate / Sponsor Account'}
                      </div>
                    </button>
                  ))}
                </div>
              </div>

              {payMode !== 'Self' ? (
                <div className="p-4 bg-slate-50 rounded-lg border border-slate-200 space-y-3">
                  <div className="flex items-center gap-2 text-slate-800 font-medium text-xs">
                    <ShieldCheck className="w-4 h-4 text-emerald-600" />
                    Insurance Policy Verification Details
                  </div>
                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                    <div>
                      <label className="text-[11px] font-medium text-slate-600 block mb-1">Insurance Company / TPA</label>
                      <input
                        type="text"
                        value={insuranceProvider}
                        onChange={(e) => setInsuranceProvider(e.target.value)}
                        placeholder="e.g. Aetna, Blue Cross, Cigna, Daman"
                        className="w-full bg-white border border-slate-300 rounded-lg p-2 text-xs focus:ring-2 focus:ring-blue-500 focus:outline-hidden"
                      />
                    </div>
                    <div>
                      <label className="text-[11px] font-medium text-slate-600 block mb-1">Policy / Member ID</label>
                      <input
                        type="text"
                        value={policyNumber}
                        onChange={(e) => setPolicyNumber(e.target.value)}
                        placeholder="e.g. POL-849204"
                        className="w-full bg-white border border-slate-300 rounded-lg p-2 text-xs focus:ring-2 focus:ring-blue-500 focus:outline-hidden"
                      />
                    </div>
                  </div>
                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                    <div>
                      <label className="text-[11px] font-medium text-slate-600 block mb-1">Patient Copay (%)</label>
                      <input
                        type="number"
                        min={0}
                        max={100}
                        value={copayPercent}
                        onChange={(e) => setCopayPercent(Number(e.target.value))}
                        className="w-full bg-white border border-slate-300 rounded-lg p-2 text-xs focus:ring-2 focus:ring-blue-500 focus:outline-hidden"
                      />
                    </div>
                    <div>
                      <label className="text-[11px] font-medium text-slate-600 block mb-1">Pre-Authorization Status</label>
                      <div className="flex items-center gap-1.5 py-2 text-xs text-emerald-700 font-medium">
                        <CheckCircle2 className="w-4 h-4 text-emerald-600" />
                        Eligible for Automated Electronic eClaims
                      </div>
                    </div>
                  </div>
                </div>
              ) : (
                <div className="p-4 bg-amber-50 rounded-lg border border-amber-200 text-amber-800 text-xs flex items-start gap-2">
                  <AlertCircle className="w-4 h-4 text-amber-600 shrink-0 mt-0.5" />
                  <div>
                    <span className="font-semibold">Self-Pay Policy Notice:</span>
                    <p className="mt-0.5 text-amber-700">
                      Patient is registered as self-pay. Hospital tariff items will be billed directly to the patient invoice with zero insurance deduction.
                    </p>
                  </div>
                </div>
              )}
            </div>
          )}

          {/* Footer Controls */}
          <div className="pt-4 border-t border-slate-200 flex items-center justify-between">
            <button
              type="button"
              onClick={onClose}
              className="px-4 py-2 text-xs font-medium text-slate-600 hover:text-slate-900 border border-slate-300 rounded-lg hover:bg-slate-50 transition-colors cursor-pointer"
            >
              Cancel
            </button>
            <div className="flex items-center gap-2">
              {activeTab !== 'insurance' ? (
                <button
                  type="button"
                  onClick={() => {
                    if (activeTab === 'demographics') setActiveTab('contact');
                    else if (activeTab === 'contact') setActiveTab('clinical');
                    else if (activeTab === 'clinical') setActiveTab('insurance');
                  }}
                  className="px-4 py-2 text-xs font-medium bg-slate-100 text-slate-800 hover:bg-slate-200 rounded-lg transition-colors cursor-pointer"
                >
                  Next Step
                </button>
              ) : null}
              <button
                type="submit"
                className="px-5 py-2 text-xs font-semibold bg-blue-600 text-white hover:bg-blue-700 rounded-lg shadow-xs flex items-center gap-1.5 transition-colors cursor-pointer"
              >
                <CheckCircle2 className="w-4 h-4" />
                {initialPatientId ? 'Save Changes' : 'Complete Admission'}
              </button>
            </div>
          </div>
        </form>
      </div>
    </div>
  );
};
