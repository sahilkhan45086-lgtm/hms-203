import React, { useState } from 'react';
import {
  Search,
  User,
  Activity,
  ReceiptText,
  Calendar,
  FileText,
  Clock,
  Printer,
  ChevronRight,
  Stethoscope,
  ShieldCheck,
  CreditCard,
  Building,
} from 'lucide-react';
import { useHospital } from '../context/HospitalContext';
import { Patient } from '../types';

export const PatientEnquiryView: React.FC = () => {
  const { patients, appointments, invoices, setActiveTab, setSelectedPatientId } = useHospital();
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedPatientIdInternal, setSelectedPatientIdInternal] = useState<string>(
    patients[0]?.id || ''
  );

  const selectedPatient =
    patients.find((p) => p.id === selectedPatientIdInternal) || patients[0];

  const matchingPatients = searchQuery.trim()
    ? patients.filter(
        (p) =>
          p.firstName.toLowerCase().includes(searchQuery.toLowerCase()) ||
          p.lastName.toLowerCase().includes(searchQuery.toLowerCase()) ||
          p.id.toLowerCase().includes(searchQuery.toLowerCase()) ||
          p.phone.includes(searchQuery) ||
          p.email.toLowerCase().includes(searchQuery.toLowerCase())
      )
    : patients;

  const patientAppointments = appointments.filter((a) => a.patientId === selectedPatient?.id);
  const patientInvoices = invoices.filter((i) => i.patientId === selectedPatient?.id);
  const totalBilled = patientInvoices.reduce(
    (sum, inv) => sum + (Number(inv.totalAmount ?? inv.subtotal) || 0),
    0
  );
  const totalPaid = patientInvoices.reduce(
    (sum, inv) => sum + (Number(inv.amountPaid) || 0),
    0
  );
  const totalOutstanding = patientInvoices.reduce(
    (sum, inv) => sum + (Number(inv.balanceDue) || 0),
    0
  );

  const handlePrint = () => {
    window.print();
  };

  return (
    <div className="p-4 lg:p-6 space-y-4 max-w-7xl mx-auto">
      {/* Top Header */}
      <div className="bg-white rounded-xl border border-slate-200 shadow-sm p-4 sm:p-5 flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div>
          <div className="flex items-center gap-2 mb-1">
            <div className="w-8 h-8 rounded-lg bg-blue-50 text-blue-600 flex items-center justify-center font-bold">
              <Search className="w-4 h-4" />
            </div>
            <h2 className="text-base font-bold text-slate-900 tracking-tight">
              Patient Facility Enquiry & Master Profile
            </h2>
            <span className="text-[10px] font-mono px-2 py-0.5 rounded bg-blue-50 text-blue-700 border border-blue-200 font-bold uppercase">
              RECORDS DESK
            </span>
          </div>
          <p className="text-xs text-slate-500 max-w-2xl">
            Single-pane inspection for patient admission logs, EMR chart diagnoses, assigned physician rounds, diagnostic reports, and itemized billing ledger.
          </p>
        </div>

        <div className="flex items-center gap-2 shrink-0">
          <button
            onClick={handlePrint}
            className="px-3 py-2 bg-slate-100 hover:bg-slate-200 border border-slate-200 text-slate-700 rounded-lg text-xs font-semibold flex items-center gap-1.5 transition cursor-pointer"
          >
            <Printer className="w-3.5 h-3.5" />
            <span>Print Patient Summary</span>
          </button>
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-12 gap-4">
        {/* Left Col: Patient Search Directory */}
        <div className="lg:col-span-4 bg-white rounded-xl border border-slate-200 shadow-sm p-3.5 flex flex-col max-h-[750px]">
          <div className="mb-3">
            <div className="relative">
              <Search className="w-3.5 h-3.5 text-slate-400 absolute left-3 top-1/2 -translate-y-1/2" />
              <input
                type="text"
                placeholder="Search MRN, Name, Phone..."
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                className="w-full bg-slate-50 border border-slate-300 rounded-lg py-1.5 pl-8 pr-3 text-xs focus:ring-2 focus:ring-blue-500/20 text-slate-900"
              />
            </div>
          </div>

          <div className="overflow-y-auto divide-y divide-slate-100 flex-1 space-y-1">
            {matchingPatients.map((p) => {
              const isSelected = p.id === selectedPatient?.id;
              return (
                <div
                  key={p.id}
                  onClick={() => setSelectedPatientIdInternal(p.id)}
                  className={`p-2.5 rounded-lg cursor-pointer transition flex items-center justify-between ${
                    isSelected
                      ? 'bg-blue-50 border border-blue-200 text-blue-900'
                      : 'hover:bg-slate-50 text-slate-700 border border-transparent'
                  }`}
                >
                  <div className="min-w-0 pr-2">
                    <div className="font-bold text-xs truncate flex items-center gap-1.5">
                      <span>{p.firstName} {p.lastName}</span>
                      <span className="text-[10px] text-slate-400 font-mono">({p.id})</span>
                    </div>
                    <div className="text-[10px] text-slate-500 truncate">
                      {p.age}y · {p.gender} · {p.phone}
                    </div>
                  </div>
                  <span
                    className={`text-[9px] font-bold px-1.5 py-0.5 rounded shrink-0 ${
                      p.status === 'Emergency'
                        ? 'bg-rose-100 text-rose-700'
                        : p.status === 'Inpatient'
                        ? 'bg-indigo-100 text-indigo-700'
                        : 'bg-emerald-100 text-emerald-700'
                    }`}
                  >
                    {p.status}
                  </span>
                </div>
              );
            })}
          </div>
        </div>

        {/* Right Col: Comprehensive Patient Details Dossier */}
        {selectedPatient ? (
          <div className="lg:col-span-8 space-y-4">
            {/* Header Card */}
            <div className="bg-white rounded-xl border border-slate-200 shadow-sm p-4">
              <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-3 pb-3 border-b border-slate-100">
                <div className="flex items-center gap-3">
                  <div className="w-12 h-12 rounded-full bg-blue-100 text-blue-700 font-bold text-sm flex items-center justify-center font-mono">
                    {selectedPatient.bloodGroup}
                  </div>
                  <div>
                    <h3 className="text-base font-bold text-slate-900 flex items-center gap-2">
                      <span>{selectedPatient.firstName} {selectedPatient.lastName}</span>
                      <span className="font-mono text-xs text-blue-600 bg-blue-50 px-2 py-0.5 rounded border border-blue-200 font-bold">
                        {selectedPatient.id}
                      </span>
                    </h3>
                    <p className="text-xs text-slate-500">
                      DOB: {selectedPatient.age} years old · {selectedPatient.gender} · Phone: {selectedPatient.phone}
                    </p>
                  </div>
                </div>

                <div className="flex items-center gap-2">
                  <button
                    onClick={() => {
                      setSelectedPatientId(selectedPatient.id);
                      setActiveTab('patients');
                    }}
                    className="px-3 py-1.5 bg-blue-600 hover:bg-blue-500 text-white rounded-lg text-xs font-bold transition flex items-center gap-1 cursor-pointer"
                  >
                    <span>Open Clinical EMR</span>
                    <ChevronRight className="w-3.5 h-3.5" />
                  </button>
                </div>
              </div>

              {/* Vitals Summary Strip */}
              <div className="grid grid-cols-2 sm:grid-cols-4 gap-2 pt-3">
                <div className="p-2 bg-slate-50 rounded border border-slate-100 text-xs">
                  <span className="text-[10px] text-slate-400 uppercase font-bold block">Blood Pressure</span>
                  <span className="font-bold text-slate-800 font-mono text-sm">
                    {selectedPatient.vitals.bloodPressure}
                  </span>
                </div>
                <div className="p-2 bg-slate-50 rounded border border-slate-100 text-xs">
                  <span className="text-[10px] text-slate-400 uppercase font-bold block">Heart Rate</span>
                  <span className="font-bold text-slate-800 font-mono text-sm">
                    {selectedPatient.vitals.heartRate} bpm
                  </span>
                </div>
                <div className="p-2 bg-slate-50 rounded border border-slate-100 text-xs">
                  <span className="text-[10px] text-slate-400 uppercase font-bold block">SpO2 Oxygen</span>
                  <span className="font-bold text-slate-800 font-mono text-sm">
                    {selectedPatient.vitals.oxygenSaturation}%
                  </span>
                </div>
                <div className="p-2 bg-slate-50 rounded border border-slate-100 text-xs">
                  <span className="text-[10px] text-slate-400 uppercase font-bold block">Attending Doctor</span>
                  <span className="font-bold text-slate-800 truncate block">
                    {selectedPatient.primaryPhysicianName}
                  </span>
                </div>
              </div>
            </div>

            {/* Medical History & Diagnoses */}
            <div className="bg-white rounded-xl border border-slate-200 shadow-sm p-4 space-y-3">
              <h4 className="text-xs font-bold uppercase tracking-wider text-slate-800 flex items-center gap-1.5">
                <FileText className="w-3.5 h-3.5 text-blue-600" />
                <span>Documented Clinical History & Chronic Conditions</span>
              </h4>
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 text-xs">
                <div className="p-2.5 bg-slate-50 rounded border border-slate-200">
                  <span className="text-[10px] uppercase font-bold text-slate-400 block mb-1">
                    Known Drug Allergies
                  </span>
                  <div className="flex flex-wrap gap-1">
                    {(selectedPatient.allergies || []).length > 0 ? (
                      (selectedPatient.allergies || []).map((a, idx) => {
                        const label = typeof a === 'string' ? a : `${a.allergen}${a.severity ? ` (${a.severity})` : ''}`;
                        const key = typeof a === 'string' ? `${a}-${idx}` : `${a.allergen}-${idx}`;
                        return (
                          <span
                            key={key}
                            className="px-2 py-0.5 rounded bg-rose-50 text-rose-700 border border-rose-200 font-semibold text-[11px]"
                          >
                            {label}
                          </span>
                        );
                      })
                    ) : (
                      <span className="text-slate-400">No known allergies (NKDA)</span>
                    )}
                  </div>
                </div>

                <div className="p-2.5 bg-slate-50 rounded border border-slate-200">
                  <span className="text-[10px] uppercase font-bold text-slate-400 block mb-1">
                    Chronic Pathologies
                  </span>
                  <div className="flex flex-wrap gap-1">
                    {(selectedPatient.chronicConditions || []).length > 0 ? (
                      (selectedPatient.chronicConditions || []).map((c, idx) => (
                        <span
                          key={`${c}-${idx}`}
                          className="px-2 py-0.5 rounded bg-blue-50 text-blue-700 border border-blue-200 font-semibold text-[11px]"
                        >
                          {c}
                        </span>
                      ))
                    ) : (
                      <span className="text-slate-400">No chronic conditions logged</span>
                    )}
                  </div>
                </div>
              </div>
            </div>

            {/* Appointments History */}
            <div className="bg-white rounded-xl border border-slate-200 shadow-sm overflow-hidden">
              <div className="p-3 border-b border-slate-200 flex items-center justify-between bg-slate-50/50">
                <div className="flex items-center gap-2">
                  <Calendar className="w-3.5 h-3.5 text-blue-600" />
                  <h4 className="text-xs font-bold uppercase tracking-wider text-slate-800">
                    Appointments & Consultations ({patientAppointments.length})
                  </h4>
                </div>
              </div>
              <div className="divide-y divide-slate-100 max-h-48 overflow-y-auto text-xs">
                {patientAppointments.length === 0 ? (
                  <div className="p-4 text-center text-slate-400">No appointments recorded.</div>
                ) : (
                  patientAppointments.map((a) => (
                    <div key={a.id} className="p-3 flex items-center justify-between hover:bg-slate-50">
                      <div>
                        <span className="font-bold text-slate-800 block">{a.doctorName} ({a.department})</span>
                        <span className="text-[11px] text-slate-500">{a.chiefComplaint}</span>
                      </div>
                      <div className="text-right">
                        <span className="font-mono font-bold text-slate-700 block">{a.date} · {a.timeSlot}</span>
                        <span className="text-[10px] font-bold text-blue-600 uppercase">{a.status}</span>
                      </div>
                    </div>
                  ))
                )}
              </div>
            </div>

            {/* Billing Ledger */}
            <div className="bg-white rounded-xl border border-slate-200 shadow-sm overflow-hidden">
              <div className="p-3 border-b border-slate-200 flex items-center justify-between bg-slate-50/50">
                <div className="flex items-center gap-2">
                  <CreditCard className="w-3.5 h-3.5 text-indigo-600" />
                  <h4 className="text-xs font-bold uppercase tracking-wider text-slate-800">
                    Billing Ledger & Invoices ({patientInvoices.length})
                  </h4>
                </div>
                <div className="text-xs font-mono">
                  <span className="text-slate-500">Balance Due: </span>
                  <span className="font-bold text-rose-600">
                    ${(Number(totalOutstanding) || 0).toFixed(2)}
                  </span>
                </div>
              </div>
              <div className="divide-y divide-slate-100 max-h-48 overflow-y-auto text-xs">
                {patientInvoices.length === 0 ? (
                  <div className="p-4 text-center text-slate-400">No invoices issued for this patient.</div>
                ) : (
                  patientInvoices.map((inv) => (
                    <div key={inv.id} className="p-3 flex items-center justify-between hover:bg-slate-50">
                      <div>
                        <div className="font-mono font-bold text-slate-800 flex items-center gap-2">
                          <span>{inv.id}</span>
                          <span className="text-[10px] text-slate-400">Issued: {inv.issueDate}</span>
                        </div>
                        <div className="text-[11px] text-slate-500">
                          {inv.items.length} itemized procedures / medications
                        </div>
                      </div>
                      <div className="text-right font-mono">
                        <div className="font-bold text-slate-900">
                          ${(Number(inv.totalAmount ?? inv.subtotal) || 0).toFixed(2)}
                        </div>
                        <span
                          className={`text-[9px] font-bold uppercase px-1.5 py-0.2 rounded ${
                            inv.status === 'Paid'
                              ? 'bg-emerald-100 text-emerald-800'
                              : 'bg-amber-100 text-amber-800'
                          }`}
                        >
                          {inv.status}
                        </span>
                      </div>
                    </div>
                  ))
                )}
              </div>
            </div>
          </div>
        ) : (
          <div className="lg:col-span-8 bg-white rounded-xl border border-slate-200 p-12 text-center text-slate-400">
            Select a patient from the directory to inspect their complete medical dossier.
          </div>
        )}
      </div>
    </div>
  );
};
