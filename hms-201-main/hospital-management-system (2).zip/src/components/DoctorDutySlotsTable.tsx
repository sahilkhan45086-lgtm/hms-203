import React, { useState } from 'react';
import {
  Calendar,
  Clock,
  CheckCircle2,
  AlertCircle,
  Plus,
  Video,
  UserCheck,
  Stethoscope,
} from 'lucide-react';
import { useHospital } from '../context/HospitalContext';
import { Doctor } from '../types';

interface DoctorDutySlotsTableProps {
  onBookSlot?: (doctorId: string, date: string, timeSlot: string) => void;
}

export const DoctorDutySlotsTable: React.FC<DoctorDutySlotsTableProps> = ({ onBookSlot }) => {
  const { doctors, appointments } = useHospital();
  const [selectedDoctorId, setSelectedDoctorId] = useState<string>(doctors[0]?.id || '');
  const [selectedDate, setSelectedDate] = useState<string>(
    new Date().toISOString().split('T')[0]
  );

  const selectedDoc = doctors.find((d) => d.id === selectedDoctorId) || doctors[0];

  const standardTimeSlots = [
    '08:30 AM',
    '09:00 AM',
    '09:30 AM',
    '10:00 AM',
    '10:30 AM',
    '11:00 AM',
    '11:30 AM',
    '01:00 PM',
    '01:30 PM',
    '02:00 PM',
    '02:30 PM',
    '03:00 PM',
    '03:30 PM',
    '04:00 PM',
  ];

  const bookedSlots = appointments
    .filter((a) => a.doctorId === selectedDoctorId && a.date === selectedDate)
    .map((a) => a.timeSlot);

  return (
    <div className="bg-white rounded-xl border border-slate-200 shadow-sm p-4 space-y-4">
      <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-3 pb-3 border-b border-slate-200">
        <div className="flex items-center gap-2">
          <Stethoscope className="w-5 h-5 text-blue-600" />
          <div>
            <h3 className="text-xs font-bold uppercase tracking-wider text-slate-800">
              Doctor Consultation Duty & Slot Roster
            </h3>
            <p className="text-[11px] text-slate-500">
              Inspect availability and instantly book OPD slots
            </p>
          </div>
        </div>

        <div className="flex items-center gap-2 w-full sm:w-auto">
          <select
            value={selectedDoctorId}
            onChange={(e) => setSelectedDoctorId(e.target.value)}
            className="bg-slate-50 border border-slate-300 rounded-lg p-1.5 text-xs font-medium text-slate-800"
          >
            {doctors.map((d) => (
              <option key={d.id} value={d.id}>
                {d.name} ({d.specialty})
              </option>
            ))}
          </select>

          <input
            type="date"
            value={selectedDate}
            onChange={(e) => setSelectedDate(e.target.value)}
            className="bg-slate-50 border border-slate-300 rounded-lg p-1.5 text-xs font-mono text-slate-800"
          />
        </div>
      </div>

      {selectedDoc && (
        <div className="p-3 bg-slate-50 border border-slate-200 rounded-lg flex flex-wrap items-center justify-between gap-3 text-xs">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-full bg-blue-100 text-blue-700 font-bold text-xs flex items-center justify-center">
              {selectedDoc.name.split(' ').map((n) => n[0]).join('').slice(0, 2)}
            </div>
            <div>
              <div className="font-bold text-slate-900">{selectedDoc.name}</div>
              <div className="text-[11px] text-slate-500">
                {selectedDoc.specialty} · {selectedDoc.department} · Room: {selectedDoc.roomNumber}
              </div>
            </div>
          </div>
          <div className="flex items-center gap-2">
            <span
              className={`px-2 py-0.5 rounded text-[10px] font-bold ${
                selectedDoc.status === 'Available'
                  ? 'bg-emerald-100 text-emerald-800'
                  : selectedDoc.status === 'In Surgery'
                  ? 'bg-rose-100 text-rose-800'
                  : 'bg-amber-100 text-amber-800'
              }`}
            >
              ● {selectedDoc.status}
            </span>
            <span className="text-[11px] text-slate-500">
              Shift: {selectedDoc.shift} ({selectedDoc.telehealthEnabled ? 'Telehealth Active' : 'In-Person Only'})
            </span>
          </div>
        </div>
      )}

      {/* Slots Grid */}
      <div>
        <div className="text-[10px] uppercase font-bold text-slate-400 mb-2 tracking-wider">
          Available Time Slots for {selectedDate}
        </div>
        <div className="grid grid-cols-2 sm:grid-cols-4 lg:grid-cols-7 gap-2">
          {standardTimeSlots.map((slot) => {
            const isBooked = bookedSlots.includes(slot);
            return (
              <button
                key={slot}
                disabled={isBooked}
                onClick={() => onBookSlot && onBookSlot(selectedDoctorId, selectedDate, slot)}
                className={`p-2.5 rounded-lg border text-center transition flex flex-col items-center justify-between gap-1 cursor-pointer ${
                  isBooked
                    ? 'bg-slate-100 border-slate-200 text-slate-400 cursor-not-allowed opacity-60'
                    : 'bg-white border-blue-200 hover:border-blue-600 hover:bg-blue-50 text-slate-800 shadow-2xs'
                }`}
              >
                <span className="font-mono text-xs font-bold">{slot}</span>
                <span className="text-[9px] font-semibold">
                  {isBooked ? 'Booked' : 'Available'}
                </span>
              </button>
            );
          })}
        </div>
      </div>
    </div>
  );
};
